
// Name: Aaron Schanz
// ID: V00936095


#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include "pman_list.h"

// this function starts a background program specified by the command line and appends it to a linked list.
void bg_entry(char **argv){
	pid_t pid = fork();
	char* file = argv[0];

	if(pid == 0){
		if(execvp(argv[0], argv) < 0){
			perror("Error on execvp");
		}
		exit(EXIT_SUCCESS);}
	else if(pid > 0) {
		// store information of the background child process in the linked list 
		insertEnd(pid, file);
	}
	else {
		perror("fork failed");
		exit(EXIT_FAILURE);
	}
}

// this function prints a list of all current background processes.
void bglist_entry() {	
	struct node *cur = head;

	int i = 0;
	printf("\n");

 	while (cur != NULL) {

		printf("%d%s\t%s\n", cur->pid, ":", cur->file);

		cur = cur->next;
		i++;
	}
	printf("%s%d\n\n", "Total Background Jobs: ", i);
	
}

// this function sends a signal to a given pid.
void bgsig_entry(char *pidS, char *sigType) {
	
	int contains = 0;
	int retVal;
	pid_t pid = atoi(pidS);

	// check that pid is present in list
	struct node *cur = head;
	while (cur != NULL) {
		if (cur->pid == pid)
			contains = 1;

		cur = cur->next;
	}
	if (contains == 0)
		printf("PID doesn't exist in list \n");

	// send signal to pid 
		// kill
	if (strcmp(sigType, "bgkill") == 0) {
		kill(pid, SIGTERM);

		// pause
	} else if (strcmp(sigType, "bgstop") == 0) {
		retVal = kill(pid, SIGSTOP);
		if (retVal == 0) 
			printf("%s%d\n", "Successfully paused PID: ", pid);
		else
			printf("%s%d\n", "Failed to pause PID: ", pid);

		// start
	} else if (strcmp(sigType, "bgstart") == 0) {	
		retVal = kill(pid, SIGCONT);
		if (retVal == 0) 
			printf("%s%d\n", "Successfully restarted PID: ", pid);
		else
			printf("%s%d\n", "Failed to restart PID: ", pid);

	} else {
		printf("Invalid signal");
	}

}

// this function prints a list of stats for a given pid.
void pstat_entry(char *pidS) {

	int contains = 0;
	pid_t pid = atoi(pidS);

	// check that pid is present in list
	struct node *cur = head;
	while (cur != NULL) {
		if (cur->pid == pid)
			contains = 1;

		cur = cur->next;
	}
	if (contains == 0) {
		printf("%s%d%s", "Error: Process ", pid, " does not exist.\n");
		return;
	}

	char *stats = (char *)malloc(sizeof(char*) * 9999);
	strcpy(stats, "/proc/");
    strcat(stats, pidS);
    strcat(stats, "/stat");

	char *status = (char *)malloc(sizeof(char*) * 9999);
	strcpy(status, "/proc/");
    strcat(status, pidS);
    strcat(status, "/status");

	char comm[1024];	// %s
	char state;		// %c
	float utime;		// %f
	float stime;		// %f
	long rss;			// %ld
	char voluntary_ctxt_switches[1024];		// %s
	char nonvoluntary_ctxt_switches[1024];		// %s

	// open /proc/<pid>/stat and /proc/<pid>/status
	FILE *statsFile = fopen(stats, "r");
	FILE *statusFile = fopen(status, "r");

	// scan relevant stats to variables
	fscanf(statsFile, "%*d %s %c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %f %f %*d %*d %*d %*d %*d %*d %*u %*u %ld", 
					comm, &state, &utime, &stime, &rss);

	fclose(statsFile);

	utime = utime / sysconf(_SC_CLK_TCK);
    stime = stime / sysconf(_SC_CLK_TCK); 

	int count = 1;
    char line[1024];

    //ctxt_switch information stored at line 54 & 55 
    while(fgets(line, sizeof(line), statusFile) != NULL){
        if(count == 54){
            strcpy(voluntary_ctxt_switches, line);
        }
        if(count == 55){
            strcpy(nonvoluntary_ctxt_switches, line);
            break;
        }
        count++;
    }
	
	fclose(statusFile);
	
	// printing and formatting stats
	printf("%s%d%s\n\n", "Process ", pid, " Stats: ");
	printf("%s%s\n", "comm:\t\t\t\t", comm);
	printf("%s%c\n", "state:\t\t\t\t", state);
	printf("%s%f\n", "utime:\t\t\t\t", utime);
	printf("%s%f\n", "stime:\t\t\t\t", stime);
	printf("%s%ld\n", "rss:\t\t\t\t", rss);
	printf("%s", voluntary_ctxt_switches);
	printf("%s\n", nonvoluntary_ctxt_switches);


}

// this function uses waitpid() to terminate zombie processes
void check_zombieProcess(void){
	int status;
	int retVal = 0;
	
	while(1) {
		usleep(100000);
		if(head == NULL){
			return ;
		}
		retVal = waitpid(-1, &status, WNOHANG);
		if(retVal > 0) {
			printf("Successfully terminated PID: %d \n", retVal);
			delete(retVal);
		}
		else if(retVal == 0){
			break;
		}
		else{
			perror("waitpid failed");
			exit(EXIT_FAILURE);
		}
	}
	return ;
}

int main(){

	while(1){	
		char *buffer = "";
		char *cmd = readline("PMan: > ");
		char **argv = (char **)malloc(sizeof(char**) * 9999);
		
		// parsing  the command line input 
		int i = 0;
		buffer = strtok(cmd, " ");
		if (buffer == NULL)
			continue;
		do{
            argv[i] = strtok(NULL," ");
        } while(argv[i++]);

		// depending on what the buffer is, appropriate function is called with relevant parameters
		if (strcmp(buffer,"bg")==0) {
			bg_entry(argv);
		}
		else if(strcmp(buffer,"bglist")==0){
			bglist_entry();
		}
		else if(strcmp(buffer,"bgkill")==0 || strcmp(buffer,"bgstop")==0 || strcmp(buffer,"bgstart")==0) {
			if (argv[0]) {
				bgsig_entry(argv[0], buffer);
			} else {
				printf("Please provide a PID\n");
			}
		}
		else if(strcmp(buffer,"pstat")==0){
			if (argv[0]) {
				pstat_entry(argv[0]);
			} else {
				printf("Please provide a PID\n");
			}
		}
		else if (strcmp(buffer, "exit") == 0) {
			return 0;
		}
		else {
			printf("%s: %s\n", buffer, "command not found");
			continue; 
		}
		check_zombieProcess();
		
	free(cmd);}
	return 0;
}