#include "pman_list.h"


// print the linked list
void printList() {
   struct node *ptr = head;
	
   while(ptr != NULL) {
      printf("(%d,%s)\n ",ptr->pid,ptr->file);
      ptr = ptr->next;
   }
}

// insert a node at the end of the linked list
void insertEnd(pid_t pid, char *file) {
   struct node *link = (struct node*) malloc(sizeof(struct node));
	
   if (link == NULL) { 
      perror("malloc failed");
   }

   link->next = NULL;
   link->pid = pid;
   link->file = strdup(file);

    if (head == NULL) {
        head = link;
    } else {
        struct node *current = head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = link;
    }
}

// delete a node with given pid
struct node* delete(pid_t pid) {

   struct node* current = head;
   struct node* previous = NULL;
	
   if(head == NULL) {
      return NULL;
   }

   while(current->pid != pid) {

      if(current->next == NULL) {
         return NULL;
      } else {
         previous = current;
         current = current->next;
      }
   }

   if(current == head) {
      head = head->next;
   } else {
      previous->next = current->next;
   }    
	
   return current;
}